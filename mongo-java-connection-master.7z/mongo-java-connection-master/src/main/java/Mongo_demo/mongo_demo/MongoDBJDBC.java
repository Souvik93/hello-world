package Mongo_demo.mongo_demo;

import java.util.Collection;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class MongoDBJDBC {
	
	
	 public static void main( String args[] ) {
			
	      try{
			
	         // To connect to mongodb server
	         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );
				
	         // Now connect to your databases
	         DB db = mongoClient.getDB( "test" );
	         System.out.println("Connect to database successfully");
	         //boolean auth = db.authenticate(myUserName, myPassword);
	         //System.out.println("Authentication: "+auth);
	         
	         Collection<DB> dbs = mongoClient.getUsedDatabases();
	         System.out.println(dbs);
	         
	         DBCollection coll = db.getCollection("souvik");
	         System.out.println("Collection created successfully");
	         BasicDBObject doc = new BasicDBObject("title", "MYSql1").
	                 append("description", "database11").
	                 append("likes", 100).
	                 append("url", "http://www.tutorialspoint.com/mongodb/").
	                 append("by", "BNa");
	     				
	              //coll.insert(doc);
	              //ystem.out.println("Document inserted successfully");
	              //coll.updateOne(eq("likes", 100), new BasicDBObject("$set", new BasicDBObject("likes", 110)));
	              
	              
	         //coll.updateOne(("title":'MYSql'), new Document("$set", new Document("i", 110)));
	     
	              
	              
	            //  BasicDBObject query = new BasicDBObject();
	              
	              BasicDBObject newDocument = new BasicDBObject();
	              //newDocument.put("likes", 20);
	              
	              newDocument.append("$set", new BasicDBObject().append("likes", 500));

	              
	              BasicDBObject uDocument = new BasicDBObject().append("title", "MongoDB");
	              
	              //uDocument.put(, newDocument);
	              
	              
	           coll.update(uDocument, newDocument,false,true);
	              
	              DBCursor cursor1 = coll.find();
	              while (cursor1.hasNext()) { 
	            	 /* DBObject updateDocument = cursor1.next();
	            	  updateDocument.put("likes","200");
	                  coll.update(updateDocument, updateDocument); */
	                 //System.out.println("Inserted Document: "+i); 
	                 System.out.println(cursor1.next()); 
	                 //i++;
	              }
				
	      }catch(Exception e){
	         System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      }
	   }

}
